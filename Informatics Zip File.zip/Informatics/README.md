"Alpha Hotel Search & Weather. Download the .exe file to run" 
